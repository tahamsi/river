### Table 10. Conflict versus temporal evolution

Confusion matrix separating concurrent disagreement from temporal evolution.

| baseline | gold_state | predicted_disputed | predicted_evolution | predicted_other | n |
| --- | --- | --- | --- | --- | --- |
| naive_rag | disputed | 0 | 0 | 0 | 0 |
| naive_rag | evolution | 0 | 0 | 0 | 0 |
| naive_rag | other | 0 | 0 | 0 | 0 |
| stateless_rag | disputed | 0 | 0 | 0 | 0 |
| stateless_rag | evolution | 0 | 0 | 0 | 0 |
| stateless_rag | other | 0 | 0 | 0 | 0 |
| last_write_wins | disputed | 0 | 0 | 16 | 16 |
| last_write_wins | evolution | 0 | 0 | 6 | 6 |
| last_write_wins | other | 0 | 0 | 0 | 0 |
| recency_weighted | disputed | 0 | 0 | 16 | 16 |
| recency_weighted | evolution | 0 | 0 | 6 | 6 |
| recency_weighted | other | 0 | 0 | 0 | 0 |
| minicheck_no_revision | disputed | 0 | 0 | 16 | 16 |
| minicheck_no_revision | evolution | 0 | 0 | 6 | 6 |
| minicheck_no_revision | other | 0 | 0 | 0 | 0 |
| river_d | disputed | 0 | 0 | 16 | 16 |
| river_d | evolution | 2 | 0 | 4 | 6 |
| river_d | other | 0 | 0 | 0 | 0 |
| river_l | disputed | 72 | 0 | 8 | 80 |
| river_l | evolution | 0 | 4 | 26 | 30 |
| river_l | other | 0 | 0 | 0 | 0 |

- Cells are raw counts, not rates.
